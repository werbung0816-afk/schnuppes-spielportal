# Investment Report — 05.10.2026

**System:** Investment Scoring V1.0 | **Erzeugt:** 11:17 Uhr | **Aktien bewertet:** 155

---

## DEPOT-CHECK

```
Gesamtperformance                  +6.9 %   (+5,646 €)
Verfügbares Cash                 11,514.69 €
Gesamtvermögen                   87,456.33 €
Positions-P&L                       +6.2 %   (+4,407 €)
ETF-Teil                           +8.9 %   (3 ETFs, investiert 55,298 €)
Einzelaktien                       -3.2 %   (8 Aktien, investiert 16,237 €)

Einzelaktien vs. ETF        -12.1 %-Pkt.
AKTIVER MEHRWERT:     NEIN
Hinweis: Einzelaktien liegen aktuell hinter dem ETF-Teil.
```

*Basis: Kaufkurse aus ZERO-Import. Zeiträume (YTD/3M/6M) erst nach ausreichender*
*Datenbasis beurteilbar. Tagesentwicklung aus ZERO-Tagesdaten.*

---

## DEPOT-CHECK

```
Positions-P&L           +6.2 %  (+4,407 EUR)
ETF-Teil                +8.9 %  (3 ETF(s), Invest: 55,298 EUR)
Einzelaktien            -3.2 %  (8 Aktie(n), Invest: 16,237 EUR)

Einzelaktien vs. ETF  -12.1 %-Pkt.
AKTIVER MEHRWERT:     NEIN
Hinweis: Einzelaktien liegen aktuell hinter dem ETF-Teil.
```

*Datenbasis: ZERO-Kaufkurse. Zeitreihen (YTD/3M/6M) nach mehrmonatigem Betrieb.*

---

## ⚠️ Systemhinweise

> ℹ️ BREAKEVEN-STOP: MSFT — Stop 432.98 € entspricht dem Einstandskurs 429.90 €. Bitte prüfen ob dies ein bewusst gesetzter Breakeven-Stop ist.

---

## 1. Marktlage

**Regime:** NEUTRAL | **Ampel:** 🟡 GELB | **VIX:** NIEDRIG

**Führende Sektoren (Score):** Technology | Communication Services | Financial Services
**Schwächste Sektoren (Score):** Consumer Cyclical | Industrials

---

## 2. Heutige Ereignisse

**Nächste Tage:**
  *Wednesday 14.10. (+9T)*
    🔴 [US] Earnings: ASML
    🔴 [US] Earnings: BLK
    🔴 [US] Earnings: STT
  *Thursday 15.10. (+10T)*
    🔴 [US] Earnings: TSM
  *Friday 16.10. (+11T)*
    🔴 [US] Earnings: HDB
  *Tuesday 20.10. (+15T)*
    🔴 [US] Earnings: ISRG
    🔴 [US] Earnings: LMT
    🔴 [US] Earnings: NDAQ

---

## Fondsmanager-Fazit

*4 Fragen. 30 Sekunden. Dann weißt du alles.*

**🎬 HEUTE:** Kein dringender Handlungsbedarf
- **ℹ️ Breakeven-Stop:** MSFT — Stop entspricht dem Einstandskurs. Kein echter Schutz. Bitte prüfen ob Stop angehoben werden soll.
**🎯 KAUF:** WARTEN — MU Level B, kein A-Setup
**💼 DEPOT:** NVDA — Score 93 | P&L +5.3%

---

## 3. Depot-Status

**Positionen:** 11 | **Qualität:** 4× A+, 3× A, 3× B, 0× ⚠️ | **Ø Score:** 73.6
**Offenes Positions-P&L:** +6.2% (+4,407 €)
**Aktives Risiko (Aktien):** 2.8% (Limit: 5%) ✅
**ETF-Anteil:** 59,617 € (78.5% des Depots) — strategische Langfristpositionen; Schutzkurse aktiv wo gesetzt.

| Ticker | Score | Δ | Grade | P&L% | Risiko% | Status | CIO-Risiko | CIO-Chance | C/R |
|---|---|---|---|---|---|---|---|---|---|
| NVDA | 93 | 0.0 | A+ | +5.3% | 0.1% | VORBEREITUNG |
| MSFT | 90 | 0.0 | A+ | +6.9% | 0.1% | VORBEREITUNG |
| APH | 87 | 0.0 | A+ | +3.1% | 0.5% | VORBEREITUNG |
| LLY | 84 | 0.0 | A+ | +1.6% | 0.1% | VORBEREITUNG |
| V | 80 | 0.0 | A | +2.7% | 0.2% | VORBEREITUNG |
| 6861.T | 79 | 0.0 | A | +0.2% | 0.1% | VORBEREITUNG |
| IFX.DE | 70 | 0.0 | A- | -11.8% | 1.5% | VORBEREITUNG |
| TTE.PA | 67 | -0.1 | B+ | -2.3% | 0.1% | VORBEREITUNG |
| MWRE.DE | 56 | +0.2 | B | +8.9% | 0.0% | HALTEN |
| XMME.L | 56 | 0.0 | B | +9.3% | 0.0% | HALTEN |
| ZAPP.L | 48 | 0.0 | — | -6.7% | 0.1% | HALTEN |

## 3a. Investmentthese / Neuengagement-Prüfung

Tägliche Bestandsprüfung durchgeführt: **11 Positionen** — INTAKT 0, GESCHWÄCHT 0, GEBROCHEN 0, DATEN UNZUREICHEND 9, ETF SEPARAT 2.

Geprüft wird je aktivem Aktienbestand: **Würde ich ihn heute zu diesem Kurs neu kaufen?** Zusätzlich wird nach einer aktuell deutlich besseren, handelbaren Alternative gesucht. Das ist eine Prüfentscheidung und keine automatische Gewinnmitnahme.

**Ergebnis:** Keine Position weist aktuell einen bestätigten Thesis Break oder eine ausreichend deutliche bessere Alternative auf. Kein Verkauf allein aus der Theseprüfung.

---

## 4. Handlungsbedarf heute

✅ **Kein akuter Handlungsbedarf** — Depot unauffällig.
### ⚠️ Sofortmaßnahmen (während des Handels (XETRA))

---

## 5. Stop-Empfehlungen

✅ Alle Stopps aktuell — keine Anpassung nötig.

---

## 6. Verkaufssignale

✅ Kein Verkaufssignal aktiv.

---

## 6c. Technische Kandidaten — BLOCKED (Hard Gate)

| Ticker | Score | Hard Gate | Grund |
|---|---|---|---|
| GOOGL | 78 | BUY_ZONE_NOT_REACHED | Kurs 343.50 noch unterhalb der Kaufzone 365.99–369.65 |
| SMSD.L | 80 | BUY_ZONE_NOT_REACHED | Kurs 3700.00 noch unterhalb der Kaufzone 4055.17–4095.72 |
| VLTO | 75 | BUY_ZONE_NOT_REACHED | Kurs 94.68 noch unterhalb der Kaufzone 99.61–100.61 |
| TSM | 87 | BUY_ZONE_EXCEEDED | Kurs 472.78 bereits oberhalb der Kaufzone 464.18–468.82 |
| NDAQ | 74 | BUY_ZONE_NOT_REACHED | Kurs 90.33 noch unterhalb der Kaufzone 98.87–99.86 |
| 6503.T | 61 | BUY_ZONE_NOT_REACHED | Kurs 5367.00 noch unterhalb der Kaufzone 5445.73–5500.19 |
| EQIX | 72 | BUY_ZONE_NOT_REACHED | Kurs 1025.72 noch unterhalb der Kaufzone 1071.84–1082.56 |
| ECL | 68 | BUY_ZONE_NOT_REACHED | Kurs 273.70 noch unterhalb der Kaufzone 283.66–286.50 |
| DLR | 61 | BUY_ZONE_NOT_REACHED | Kurs 178.55 noch unterhalb der Kaufzone 191.74–193.66 |
| BLK | 75 | BUY_ZONE_NOT_REACHED | Kurs 1059.63 noch unterhalb der Kaufzone 1132.84–1144.17 |
| STT | 70 | BUY_ZONE_NOT_REACHED | Kurs 175.96 noch unterhalb der Kaufzone 195.34–197.29 |
| AMDUF | 65 | RR_NONE | R/R nicht vorhanden (None) |
| DWS.DE | 70 | RR_BELOW_MIN | R/R 0.70 unter Mindest-R/R 1.5 |
| NOW | 75 | RR_BELOW_MIN | R/R 0.80 unter Mindest-R/R 1.5 |
| AMZN | 77 | BUY_ZONE_NOT_REACHED | Kurs 251.52 noch unterhalb der Kaufzone 262.43–265.05 |
| LR.PA | 69 | BUY_ZONE_NOT_REACHED | Kurs 141.40 noch unterhalb der Kaufzone 147.03–148.50 |
| AI.PA | 68 | BUY_ZONE_NOT_REACHED | Kurs 172.98 noch unterhalb der Kaufzone 175.09–176.84 |
| PRY.MI | 72 | BUY_ZONE_NOT_REACHED | Kurs 126.20 noch unterhalb der Kaufzone 131.86–133.18 |
| PWR | 78 | BUY_ZONE_EXCEEDED | Kurs 676.56 bereits oberhalb der Kaufzone 667.68–674.36 |
| RWE.DE | 65 | BUY_ZONE_NOT_REACHED | Kurs 58.68 noch unterhalb der Kaufzone 61.85–62.47 |
| VWS.CO | 69 | RR_BELOW_MIN | R/R 1.20 unter Mindest-R/R 1.5 |
| SHEL.L | 68 | BUY_ZONE_NOT_REACHED | Kurs 3630.50 noch unterhalb der Kaufzone 3699.91–3736.91 |
| MTX.DE | 68 | BUY_ZONE_NOT_REACHED | Kurs 369.00 noch unterhalb der Kaufzone 382.80–386.63 |
| CBK.DE | 65 | RR_BELOW_MIN | R/R 0.80 unter Mindest-R/R 1.5 |
| DB1.DE | 78 | RR_BELOW_MIN | R/R 1.00 unter Mindest-R/R 1.5 |
| MA | 81 | BUY_ZONE_NOT_REACHED | Kurs 552.26 noch unterhalb der Kaufzone 595.93–601.89 |
| ETN | 76 | RR_BELOW_MIN | R/R 1.40 unter Mindest-R/R 1.5 |
| FPE3.DE | 69 | BUY_ZONE_NOT_REACHED | Kurs 42.78 noch unterhalb der Kaufzone 43.58–44.02 |
| DBK.DE | 64 | RR_BELOW_MIN | R/R 1.40 unter Mindest-R/R 1.5 |
| OR.PA | 65 | BUY_ZONE_NOT_REACHED | Kurs 372.70 noch unterhalb der Kaufzone 395.97–399.93 |
| FCX | 77 | RR_BELOW_MIN | R/R 0.30 unter Mindest-R/R 1.5 |
| ABI.BR | 65 | BUY_ZONE_NOT_REACHED | Kurs 65.98 noch unterhalb der Kaufzone 70.37–71.07 |
| ASML.AS | 86 | BUY_ZONE_NOT_REACHED | Kurs 1647.40 noch unterhalb der Kaufzone 1667.90–1684.58 |
| BNR.DE | 60 | RR_BELOW_MIN | R/R -0.40 unter Mindest-R/R 1.5 |
| SY1.DE | 66 | BUY_ZONE_NOT_REACHED | Kurs 91.26 noch unterhalb der Kaufzone 94.97–95.92 |
| SIE.DE | 69 | BUY_ZONE_NOT_REACHED | Kurs 272.80 noch unterhalb der Kaufzone 287.73–290.61 |
| XOM | 68 | RR_BELOW_MIN | R/R 1.00 unter Mindest-R/R 1.5 |
| LONN.SW | 73 | BUY_ZONE_NOT_REACHED | Kurs 569.60 noch unterhalb der Kaufzone 594.56–600.51 |
| ABBN.SW | 71 | RR_BELOW_MIN | R/R 0.60 unter Mindest-R/R 1.5 |
| AIR.PA | 66 | BUY_ZONE_NOT_REACHED | Kurs 189.02 noch unterhalb der Kaufzone 201.70–203.72 |
| ISP.MI | 65 | BUY_ZONE_NOT_REACHED | Kurs 6.40 noch unterhalb der Kaufzone 6.87–6.94 |
| CVX | 72 | BUY_ZONE_NOT_REACHED | Kurs 206.69 noch unterhalb der Kaufzone 218.87–221.06 |
| SAP.DE | 84 | BUY_ZONE_NOT_REACHED | Kurs 185.22 noch unterhalb der Kaufzone 191.21–193.12 |
| DHL.DE | 66 | RR_BELOW_MIN | R/R -0.10 unter Mindest-R/R 1.5 |

## 7. Top-Kaufchancen

**Technische A-Kandidaten:** 0 | **CIO-freigegebene Käufe heute:** 0 | **Ampel:** ✅ Käufe möglich

ℹ️ **Kein bestätigtes Einstiegssignal heute.** Level-A-Kandidaten ohne Trigger — Nächstbeste Beobachter (Level B):
- **Priorität 1: MU** Micron Technology, Inc. — Score 93 | KEINES | Trigger: 1114.26
- **Priorität 2: ANET** Arista Networks, Inc. — Score 93 | KEINES | Trigger: 213.06
- **Priorität 3: PLTR** Palantir Technologies Inc. — Score 90 | KEINES | Trigger: 195.65
---

## 8. Beobachtungsliste (Level B — kaufbar bei Trigger)

| Ticker | Name | Score | Setup | Trigger |
|---|---|---|---|---|
| MU | Micron Technology, Inc. | 93 | KEINES | 1114.26 |
| ANET | Arista Networks, Inc. | 93 | KEINES | 213.06 |
| PLTR | Palantir Technologies Inc. | 90 | KEINES | 195.65 |
| AMD | Advanced Micro Devices, Inc. | 88 | KEINES | 642.19 |
| TSM | Taiwan Semiconductor Manufactur | 87 | TREND_CONTINUATION | 464.18 |

---

## 9. Heute nichts tun bei

- **IFX.DE** INFINEON TECHNOLOGIES AG      N — Score 70 (A-) — Score stabil, kein Setup-Signal
- **TTE.PA** TOTALENERGIES — Score 67 (B+) — Score stabil, kein Setup-Signal
- **ZAPP.L** GLOBAL X ETFS ICAV GX U.S. ELEC — Score 48 (—) — Score stabil, kein Setup-Signal
- **MWRE.DE** Amundi Core MSCI World UCITS ETF Acc — Score 56 (B) — Score stabil, kein Setup-Signal
- **XMME.L** Xtrackers MSCI Emerging Markets UCITS ETF 1C — Score 56 (B) — Score stabil, kein Setup-Signal
- **6861.T** KEYENCE CORP — Score 79 (A) — Score stabil, kein Setup-Signal
- **APH** Amphenol Corporation — Score 87 (A+) — Score stabil, kein Setup-Signal
- **LLY** Eli Lilly and Company — Score 84 (A+) — Score stabil, kein Setup-Signal
- **MSFT** Microsoft Corporation — Score 90 (A+) — Score stabil, kein Setup-Signal
- **NVDA** NVIDIA Corporation — Score 93 (A+) — Score stabil, kein Setup-Signal
- **V** Visa Inc. — Score 80 (A) — Score stabil, kein Setup-Signal

---

## 10. Zusammenfassung

Der Markt ist uneinheitlich. Selektiv vorgehen und nur A-Setups mit hoher Konfidenz handeln. Das Depot befindet sich in guter Qualität (Ø Score: 74). Stärkste Sektoren heute: Technology, Communication Services.

---
*Erzeugt: 05.10.2026 11:17 | System V1.0 | Details: opportunity_ranking.csv | portfolio_status.csv | actions_today.csv*